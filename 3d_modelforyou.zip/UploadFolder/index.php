<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<link rel="stylesheet" href="turntable.css">

	<style>

	.container {
		max-width: 640px;
		margin: auto;
	}

	</style>

</head>
<body>
	
	<div id="myTurntable" class="turntable">
	  <ul><!--
								  	 <li data-img-src="1.jpg"></li>
					   				 <li data-img-src="2.jpg"></li>
	                                 <li data-img-src="3.jpg"></li>
                                    <li data-img-src="4.jpg"></li>
                                    <li data-img-src="5.jpg"></li>
                                    <li data-img-src="6.jpg"></li>
                                    <li data-img-src="7.jpg"></li>
                                    <li data-img-src="8.jpg"></li>
                                    <li data-img-src="9.jpg"></li>
                                    <li data-img-src="10.jpg"></li>
                                    <li data-img-src="11.jpg"></li>
                                    <li data-img-src="12.jpg"></li>
                                    <li data-img-src="13.jpg"></li>
                                    <li data-img-src="14.jpg"></li>
                                    <li data-img-src="15.jpg"></li>
                                    <li data-img-src="16.jpg"></li>
                                    <li data-img-src="17.jpg"></li>
                                    <li data-img-src="18.jpg"></li>
                                    <li data-img-src="19.jpg"></li>
                                    <li data-img-src="20.jpg"></li>
                                    <li data-img-src="21.jpg"></li>
                                    <li data-img-src="22.jpg"></li>
                                    <li data-img-src="23.jpg"></li>
                                    <li data-img-src="24.jpg"></li>
                                    <li data-img-src="25.jpg"></li>
                                    <li data-img-src="26.jpg"></li>
                                    <li data-img-src="27.jpg"></li>
                                    <li data-img-src="28.jpg"></li>
                                    <li data-img-src="29.jpg"></li>
                                    <li data-img-src="30.jpg"></li>
                                    <li data-img-src="31.jpg"></li>
                                    <li data-img-src="32.jpg"></li>
                                    <li data-img-src="33.jpg"></li>
                                    <li data-img-src="34.jpg"></li>
                                    <li data-img-src="35.jpg"></li>
                                    <li data-img-src="36.jpg"></li>
                                    <li data-img-src="37.jpg"></li>
                                    <li data-img-src="38.jpg"></li>
                                    <li data-img-src="39.jpg"></li>
                                    <li data-img-src="40.jpg"></li>
                                    <li data-img-src="41.jpg"></li>
                                    <li data-img-src="42.jpg"></li>
                                    <li data-img-src="43.jpg"></li>
                                    <li data-img-src="44.jpg"></li>
                                    <li data-img-src="45.jpg"></li>
                                    <li data-img-src="46.jpg"></li>
                                    <li data-img-src="47.jpg"></li>
                                    <li data-img-src="48.jpg"></li> -->
<?php
    $directory = "./";    // Папка с изображениями
    $allowed_types=array("jpg", "png", "gif");  //разрешеные типы изображений
    $file_parts = array();
      $ext="";
      $title="";
      $i=0;
    //пробуем открыть папку
      $dir_handle = @opendir($directory) or die("Ошибка при открытии папки !!!");
    while ($file = readdir($dir_handle))    //поиск по файлам
      {
      if($file=="." || $file == "..") continue;  //пропустить ссылки на другие папки
      $file_parts = explode(".",$file);          //разделить имя файла и поместить его в массив
      $ext = strtolower(array_pop($file_parts));   //последний элеменет - это расширение


      if(in_array($ext,$allowed_types))
      {
      echo '<li data-img-src="'.$directory.'/'.$file.'" class="pimg" title="'.$file.'" >
            </li>';
     $i++;
      }

      }
    closedir($dir_handle);  //закрыть папку
    ?>									
		</ul>
	</div>
	

	
<script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
<script src="turntable.js"></script>
<script>
	$(document).ready(function(){
		$('#myTurntable').turntable();
	});
</script>

</body>
</html>